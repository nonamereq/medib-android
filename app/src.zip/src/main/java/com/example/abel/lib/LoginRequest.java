package com.example.abel.lib;

import android.content.Context;
import android.util.Log;

import org.json.JSONObject;
import org.json.JSONException;

import java.util.Observable;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;


public class LoginRequest  extends Observable implements MedibRequest<JSONObject>{
    private Context context;
    private JSONObject response;
    private int status;
    private boolean executeCalled = false;
    private static int requestMethod = Request.Method.POST;

    public LoginRequest(Context context){
        super();
        this.context = context;
        this.response = null;
        this.status = 0;
    }

    public String getUrl(){ return Constants.LOGIN_URL; }

    public void execute(JSONObject json){
        RequestQueue requestQueue = Volley.newRequestQueue(this.context);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(requestMethod, Constants.LOGIN_URL, json, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject res) {
                response = res;
                executeCalled = true;
                setChanged();
                notifyObservers();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                executeCalled = true;
                setChanged();
                notifyObservers();
            }
        });
        requestQueue.add(jsonObjectRequest);
    }

    public boolean success(){
        boolean success = false;
        try {
            success = Boolean.parseBoolean(response.getString("success"));
        }catch(JSONException except) {
            except.printStackTrace();
        }
        return success;
    }

    public int status(){
        if(executeCalled){
            return status;
        }
        else 
            throw (new RuntimeException("You need to call execute first"));
    }

    public JSONObject getErrors(){
        if(executeCalled){
            if(response != null){
                try{
                    return response.getJSONObject("err");
                }
                catch(JSONException e){
                    return null;
                }
            }
            else
                return null;
        }
        else {
            throw (new RuntimeException("You need to call execute first"));
        }
    }

    public boolean finished(){
        return executeCalled;
    }

    public JSONObject getDoc(){
        if(executeCalled){
            if(response != null){
                try{
                    return response.getJSONObject("doc");
                }
                catch(JSONException e){
                    return null;
                }
            }
            else
                return null;
        }
        else {
            throw (new RuntimeException("You need to call execute first"));
        }
    }

    public String getString(String key) {
        String object = null;
        try {
            object = response.getString(key);
        } catch (JSONException except) {
            except.printStackTrace();
        }
        return object;
    }
}
