package com.example.abel.lib;

import org.json.JSONObject;

public interface MedibRequest<T>{
    String getUrl();

    void execute(JSONObject json);
    boolean success();
    int status();
    JSONObject getErrors();
    T getDoc();

    boolean finished();
    String getString(String key);
}
