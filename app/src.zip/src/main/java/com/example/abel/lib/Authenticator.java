package com.example.abel.lib;

import android.content.Context;

public class Authenticator {
    private static Authenticator ourInstance = null;

    String token;
    Boolean isAdmin;
    DatabaseHelper helper;
    Context context;

    static public Authenticator getInstance(Context context){
        if(ourInstance == null){
            ourInstance = new Authenticator(context.getApplicationContext());
        }
        return ourInstance;
    }

    private Authenticator(Context context){
        this.context = context;
        token = null;
        isAdmin = null;
        helper = new DatabaseHelper(context);
    }

    public String getToken(){
        if(token == null){
            token = helper.get("token");
        }
        return token;
    }

    public boolean isAdmin(){
        if(isAdmin == null){
            isAdmin = Boolean.parseBoolean(helper.get("isAdmin"));
        }
        return isAdmin;
    }

    public void storeToken(String token, boolean isAdmin){
        helper.store("token", token);
        helper.store("isAdmin", Boolean.toString(isAdmin));
    }
}
